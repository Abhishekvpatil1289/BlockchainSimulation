from blockchain.blockchain import Blockchain
from blockchain.block import Block

if __name__ == "__main__":
    blockchain = Blockchain()

    # Add blocks
    blockchain.add_block(Block(1, "Some transactions here", blockchain.get_latest_block().hash))
    blockchain.add_block(Block(2, "Some more transactions", blockchain.get_latest_block().hash))

    # Print the blockchain
    for block in blockchain.chain:
        print(f"Block {block.index} - Transactions: {block.transactions}, Hash: {block.hash}")

    # Validate blockchain
    print("Blockchain is valid:", blockchain.is_chain_valid())
