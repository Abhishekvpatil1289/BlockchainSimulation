from blockchain.blockchain import Blockchain
from blockchain.block import Block

def tamper_with_blockchain(blockchain):
    blockchain.chain[1].transactions = "Tampered Data"
    print("Tampering with block 1...")
    print("Blockchain is valid?", blockchain.is_chain_valid())

if __name__ == "__main__":
    blockchain = Blockchain()

    # Add blocks
    blockchain.add_block(Block(1, "Some transactions here", blockchain.get_latest_block().hash))
    blockchain.add_block(Block(2, "Some more transactions", blockchain.get_latest_block().hash))

    # Print the original blockchain
    for block in blockchain.chain:
        print(f"Block {block.index} - Transactions: {block.transactions}, Hash: {block.hash}")

    # Tamper with blockchain and check validity
    tamper_with_blockchain(blockchain)
